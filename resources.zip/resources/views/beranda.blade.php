@extends('template.main')
@section('content')
	<!-- Main Slider -->
			<div id="main-slider" class="main-slider">

				<!-- Item -->
				<div class="item">
					<img src="{{asset('assets')}}/images/slider-banner/bg-1.jpg" alt="">
					<div class="banner-overlay">
						<div class="container">
							<div class="position-center-x">
								<div class="caption style-1 h-white after-clear">
									<h1>HUT<i>Ke - 207<sup>th</sup></i> Bandung <span>Konser COLDPLAY</span></h1>
									<h2>The best preparation for tomorrow is doing your best today...</h2>
									<span class="dot-line"></span>
									<div class="location-list">
										<ul>
											<li><i class="icon-calendar"></i>27 Dec - 03 Jan, 2017</li>
											<li><i class="icon-clock-o"></i>09:00 - 15:00</li>
											<li><i class="icon-map-marker"></i>Eventiests, NY, USA.</li>
										</ul>
									</div>
									<ul class="btn-list">
										<li><a class="btn white" href="#">Read Details</a></li>
										<li><a class="btn" href="#">Register Online</a></li>
									</ul>
								</div>
							</div>
						</div>
					</div>
				</div>
				<!-- Item -->

				<!-- Item -->
				<div class="item">
					<img src="assets/images/slider-banner/bg-2.jpg" alt="">
					<div class="banner-overlay">
						<div class="container">
							<div class="position-center-center">
								<div class="caption center h-white after-clear">
									<h1>The <i>5<sup>th</sup></i> International Seminar<span> Business Cornor Gethering</span></h1>
									<h2>The best preparation for tomorrow is doing your best today...</h2>
									<span class="dot-line"></span>
									<div class="location-list">
										<ul>
											<li><i class="icon-calendar"></i>27 Dec - 03 Jan, 2017</li>
											<li><i class="icon-clock-o"></i>09:00 - 15:00</li>
											<li><i class="icon-map-marker"></i>Eventiests, NY, USA.</li>
										</ul>
									</div>
									<ul class="btn-list">
										<li><a class="btn white" href="#">Read Details</a></li>
										<li><a class="btn" href="#">Register Online</a></li>
									</ul>
								</div>
							</div>
						</div>
					</div>
				</div>
				<!-- Item -->

				<!-- Item -->
				<div class="item">
					<img src="assets/images/slider-banner/bg-3.jpg" alt="">
					<div class="banner-overlay">
						<div class="container">
							<div class="position-center-x">
								<div class="caption style-1 h-white after-clear">
									<h1>The <i>5<sup>th</sup></i> International <span>Business Conference</span></h1>
									<h2>The best preparation for tomorrow is doing your best today...</h2>
									<span class="dot-line"></span>
									<div class="location-list">
										<ul>
											<li><i class="icon-calendar"></i>27 Dec - 03 Jan, 2017</li>
											<li><i class="icon-clock-o"></i>09:00 - 15:00</li>
											<li><i class="icon-map-marker"></i>Eventiests, NY, USA.</li>
										</ul>
									</div>
									<ul class="btn-list">
										<li><a class="btn white" href="#">Read Details</a></li>
										<li><a class="btn" href="#">Register Online</a></li>
									</ul>
								</div>
							</div>
						</div>
					</div>
				</div>
				<!-- Item -->

			</div>
			<!-- Main Slider -->
			
		</header>
		<!-- Header -->
<!-- Mian Content -->
		<main id="main-content" class="main-coontent">
			
			<!-- Welcome Section -->
			<section class="tc-padding">
				<div class="container">

					<!-- First Row -->
					<div class="event-img-list">
						<div class="row">
							<div class="col-sm-12">
								<div class="welcome-text">
									<div class="welcome-title">
										<span class="icon-small-icon">
						                	<img src="{{asset('assets')}}/images/logo-6.png" class="text-center">
						                </span>
										<h2>Selamat Datang Di <span>Ini Bandung</span></h2>
									</div>
									<article>
										<p><q>Publikasikan Event Anda Disini</q></p>
										<p>Ini Bandung merupakan sebuah website .</p>
										<p class="none-991">   </p>
										<a class="btn" href="#">Baca Lebih Lanjut</a>
									</article>
								</div>
							</div>
						</div>
					</div>
					<!-- First Row -->

					<!-- Second Row -->
					<div class="event-img-list style-2">
						<div class="row">

							<!-- Img -->
							<div class="col-sm-3 col-xs-3 xs-full-width">
								<div class="pt-30 text-center">
									<figure class="welcome-img overlay-dark">
										<img src="{{asset('assets')}}/images/events-img/img-1-1.jpg" alt="">
									</figure>
								</div>
							</div>
							<!-- Img -->

							<!-- Img -->
							<div class="col-sm-6 col-xs-6 xs-full-width">
								<div class="img-border">
									<figure class="welcome-img overlay-dark">
										<img src="{{asset('assets')}}/images/events-img/img-1-2.jpg" alt="">
									</figure>
								</div>
							</div>
							<!-- Img -->

							<!-- Img -->
							<div class="col-sm-3 col-xs-3 xs-full-width">
								<div class="pt-30 text-center">
									<figure class="welcome-img overlay-dark">
										<img src="{{asset('assets')}}/images/events-img/img-1-3.jpg" alt="">
									</figure>
								</div>
							</div>
							<!-- Img -->

						</div>
					</div>
					<!-- Second Row -->

				</div>
			</section>


			<!-- Our Upcoming Schedules -->
			<section class="tc-padding">
				<div class="container">

					<!-- Main Heading -->
					<div class="main-heading-holder">
						<div class="main-heading">
							<h2><span>Festival & Events</span></h2>
							<span class="icon-small-icon">
			                </span>
						</div>
					</div>
					<!-- Main Heading -->

					<!-- Schedules Tabs -->
					<div class="row">

						<!-- Tabs -->
						<div class="col-xs-12 mb-50">
							<div class="tabs-holder mt-50">

								<!-- Tab Nav -->
								<div class="schedules-tab-nav" role="tablist">
									<ul>
										<li class="active"><a href="#schedules-tab1" role="tab" data-toggle="tab">..<span>..</span></a></li>
									</ul>
								</div>
								<!-- Tab Nav -->

								<!-- Tab Content -->
								<div class="tab-content">

									<!-- Days 1 -->
									<div role="tabpanel" class="tab-pane active" id="schedules-tab1">

										<!-- Schedules Widget -->
										<div class="schedules-widget">
											<div class="speaker-imgs">
												<ul>
													<li><a href="#"><img src="assets/images/event-aurhtor/img-01.jpg" alt=""><span class="toltip">David Stewart</span></a></li>
												</ul>
											</div>
											<div class="detail">
												<ul class="time-location">
													<li><i class="icon-clock"></i>09:00 am - 10:30 am</li>
													<li><i class="icon-map-marker"></i>Business Hall, Room C</li>
												</ul>
												<h3><a href="program-detail.html">Develop your Own Business and Stand in International Market</a></h3>
												<p>Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium doloremque laudantium, totam rem aperiam...[+]</p>
											</div>
										</div>
										<!-- Schedules Widget -->

										<!-- Schedules Widget -->
										<div class="schedules-widget">
											<div class="speaker-imgs">
												<ul>
													<li><a href="#"><img src="assets/images/event-aurhtor/img-02.jpg" alt=""><span class="toltip">David Stewart</span></a></li>
												</ul>
											</div>
											<div class="detail">
												<ul class="time-location">
													<li><i class="icon-clock"></i>09:00 am - 10:30 am</li>
													<li><i class="icon-map-marker"></i>Business Hall, Room C</li>
												</ul>
												<h3><a href="program-detail.html">I must explain to you how all this mistaken idea of denounce</a></h3>
												<p>Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium doloremque laudantium, totam rem aperiam...[+]</p>
												<ul class="speaker-name">
													<li><i class="icon-microphone"></i>David Stewart<span>(Marketing Manager),</span></li>
													<li>Miller Dolphin<span>(Business Developer)</span></li>
												</ul>
											</div>
										</div>
										<!-- Schedules Widget -->

										<!-- Schedules Widget -->
										<div class="schedules-widget">
											<div class="speaker-imgs">
												<ul>
													<li><a href="#"><img src="assets/images/event-aurhtor/img-03.jpg" alt=""><span class="toltip">David Stewart</span></a></li>
												</ul>
											</div>
											<div class="detail">
												<ul class="time-location">
													<li><i class="icon-clock"></i>09:00 am - 10:30 am</li>
													<li><i class="icon-map-marker"></i>Business Hall, Room C</li>
												</ul>
												<h3><a href="program-detail.html">On the other hand, we denounce with righteous</a></h3>
												<p>Eget mauris at. Dictum quis sem. Suscipit etiam facilisis interdum sed lobortis nulla penatibus pharetra. Potenti adipiscing leo. erat arcu mi libero justo turpis. Rhoncus tellus venenatis sunt taciti enim sed aliquam cursus elementum magna.</p>
											</div>
										</div>
										<!-- Schedules Widget -->

										<!-- Schedules Widget -->
										<div class="schedules-widget">
											<div class="speaker-imgs">
												<ul>
													<li><a href="#"><img src="assets/images/event-aurhtor/img-04.jpg" alt=""><span class="toltip">David Stewart</span></a></li>
												</ul>
											</div>
											<div class="detail">
												<ul class="time-location">
													<li><i class="icon-clock"></i>09:00 am - 10:30 am</li>
													<li><i class="icon-map-marker"></i>Business Hall, Room C</li>
												</ul>
												<h3><a href="program-detail.html">Open your business around the world</a></h3>
												<p>Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium doloremque laudantium, totam rem aperiam...[+]</p>
											</div>
										</div>
										<!-- Schedules Widget -->

									</div>
									<!-- Days 1 -->

								</div>
								<!-- Tab Content -->

							</div>
						</div>
						<!-- Tabs -->

					</div>
					<!-- Schedules Tabs -->

				</div>
			</section>
			
			<!-- Our Best Sponsers -->
			<section class="tc-padding gray-bg">
				<div class="container">
					
					<!-- Main Heading -->
					<div class="main-heading-holder">
						<div class="main-heading">
							<h2><span>Sponsor & media patner</span></h2>
							<span class="icon-small-icon">
			                	
			                </span>
						</div>
					</div>
					<!-- Main Heading -->

					<!-- Sponsers List -->
					<div class="sponsers-list">
						
						<!-- List 1 -->
						<div class="sponsers-slider-holder">
							<div class="sponsers-title"><h3>Best<br> Sponsor</h3></div>
							<ul class="sponsers-slider">
								<li><a href="#"><img src="{{asset('assets')}}/images/sponsers/img-01.jpg" alt=""></a></li>
								<li><a href="#"><img src="{{asset('assets')}}/images/sponsers/img-02.jpg" alt=""></a></li>
								<li><a href="#"><img src="{{asset('assets')}}/images/sponsers/img-03.jpg" alt=""></a></li>
								<li><a href="#"><img src="{{asset('assets')}}/images/sponsers/img-01.jpg" alt=""></a></li>
								<li><a href="#"><img src="{{asset('assets')}}/images/sponsers/img-01.jpg" alt=""></a></li>
							</ul>
						</div>
						<!-- List 1 -->

						<!-- List 1 -->
						<div class="sponsers-slider-holder">
							<div class="sponsers-title"><h3>Best<br> Media Patner</h3></div>
							<ul class="sponsers-slider">
								<li><a href="#"><img src="{{asset('assets')}}/images/sponsers/img-01.jpg" alt=""></a></li>
								<li><a href="#"><img src="{{asset('assets')}}/images/sponsers/img-01.jpg" alt=""></a></li>
								<li><a href="#"><img src="{{asset('assets')}}/images/sponsers/img-01.jpg" alt=""></a></li>
								<li><a href="#"><img src="{{asset('assets')}}/images/sponsers/img-01.jpg" alt=""></a></li>
								<li><a href="#"><img src="{{asset('assets')}}/images/sponsers/img-01.jpg" alt=""></a></li>
							</ul>
						</div>
						<!-- List 1 -->

					</div>
					<!-- Sponsers List -->

				</div>
			</section>
			<!-- Our Best Sponsers -->

			
		</main>
		<!-- Mian Content -->
@endsection