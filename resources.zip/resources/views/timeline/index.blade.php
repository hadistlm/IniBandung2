@extends('template.main')
@section('content')
				
		<main id="main-content" class="main-coontent">
			<style>
				.card {
				    box-shadow: 0 2px 4px 0 rgba(0,0,0,0.2);
				    transition: 0.3s;
				    background-color: #ffffff;
				    width: 28%;
				}

				.card:hover {
				    box-shadow: 0 8px 16px 0 rgba(0,0,0,0.2);
				}

				.container {
				    padding: 2px 16px;
				}

				#overlay {
				    position: fixed;
				    display: none;
				    width: 100%;
				    height: 100%;
				    top: 0;
				    left: 0;
				    right: 0;
				    bottom: 0;
				    background-color: rgba(0,0,0,0.5);
				    z-index: 10;
				    cursor: pointer;
				}
			</style>
			<div id="overlay" onclick="off()">
			<div class="position-center-center">
				<div class="card" style="margin-bottom: 5%;">
				  	<img src="{{asset('assets')}}/images/logo-6.png"  style="width:100%">
				  	<div class="container">
				    	<h4 style="padding-top: 10px;"><b>{Event-Name}</b></h4> 
				    	<p>{Event-Date}</p> 
				    	<p>{Event-Location}</p> 
				    	<p>{Event-Contact}</p> 
				    	<p>{Event-Sponsor}</p> 
				  	</div>
				</div>
			</div>
			</div>

			<div class="container" style="width: 80%; margin-top: 5%;">
					<div class="card" style="margin-bottom: 5%;">
					  	<img onclick="on()" src="{{asset('assets')}}/images/logo-6.png" alt="Avatar" style="width:100%">
					  	<div class="container">
					    	<h4 style="padding-top: 10px;"><b>{Event-Name}</b></h4> 
					    	<p>{Event-Date}</p> 
					  	</div>
					</div>
			</div>
<script>
function on() {
    document.getElementById("overlay").style.display = "block";
}

function off() {
    document.getElementById("overlay").style.display = "none";
}
</script>
		</main>
		<!-- Mian Content -->
@endsection