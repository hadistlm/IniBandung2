@extends('template.main')
@section('content')
<main id="main-content" class="main-coontent">
			<div class="container">

				<!-- Our Upcoming Schedules -->
			<section class="tc-padding">
				<div class="container">

					<!-- Main Heading -->
					<div class="main-heading-holder">
						<div class="main-heading">
							<h2><span>panel Akun</span></h2>
						</div>
					</div>
					<!-- Main Heading -->

					<!-- Schedules Tabs -->
					<div class="row">

						<!-- Tabs -->
						<div class="col-xs-12">
							<div class="tabs-holder mt-50">

								<!-- Tab Nav -->
								<div class="schedules-tab-nav" role="tablist">
									<ul>
										<li class="active"><a href="#schedules-tab1" role="tab" data-toggle="tab">Kelola<span>Akun</span></a></li>
										<li><a href="#schedules-tab2" role="tab" data-toggle="tab">Kelola<span>Event</span></a></li>
									</ul>
								</div>
								<!-- Tab Nav -->

								<!-- Tab Content -->
								<div class="tab-content">

									<!-- Days 1 -->
									<div role="tabpanel" class="tab-pane active" id="schedules-tab1">

										<!-- Schedules Widget -->
										<div class="schedules-widget">
											<div class="speaker-imgs">
												<ul>
													<li><a href="#"><img src="assets/images/event-aurhtor/img-01.jpg" alt=""><span class="toltip">Saya</span></a></li>
												</ul>
											</div>
											<div class="detail">
												<form>
												  <div class="form-group">
												    <label for="username">Username</label>
												    <input type="text" class="form-control" id="email" placeholder="Username" value="">
												  </div>
												  <div class="form-group">
												    <label for="tempat_lahir">Tempat Lahir</label>
												    <input type="text" class="form-control" id="pwd" placeholder="Tempat Lahir" value="">
												  </div>
												  <div class="form-group">
												    <label for="tgl_lahir">Tanggal Lahir</label>
												    <input type="date" class="form-control" id="pwd" placeholder="Tanggal Lahir" value="">
												  </div>
												  <div class="form-group">
												    <label for="tgl_lahir">Email</label>
												    <input type="email" class="form-control" id="pwd" placeholder="Example@mail.id" value="">
												  </div>
												  <div class="form-group">
												    <label for="tgl_lahir">No Telp</label>
												    <input type="number" class="form-control" id="pwd" placeholder="08" value="">
												  </div>

												  <button type="submit" class="btn btn-default">Simpan</button>
												</form>
											</div>
										</div>
										<!-- Schedules Widget -->
									</div>
									<!-- Days 1 -->

									<!-- Days 2 -->
									<div role="tabpanel" class="tab-pane fade" id="schedules-tab2">

										<!-- Schedules Widget -->
										<div class="schedules-widget">
											 <table id="example1" class="table table-striped table-hover">
					                            <thead>
					                                <tr>
					                                    <th>No</th>
					                                    <th>Foto</th>
					                                    <th>Nama Event</th>
					                                    <th>Tanggal</th>
					                                    <th>Lokasi</th>
					                                    <th>Aksi</th>
					                                   
					                                </tr>
					                            </thead>
					                            
					                            <tbody>
					                               
					                                <tr>
					                                    <td></td>
					                                    <td></td>
					                                    <td></td>
					                                    <td></td>
														<td></td>
					                                    <td>
					                                        <a href="#">
					                                            <i class="btn btn-warning glyphicon glyphicon-pencil"></i>
					                                        </a>
					                                        
					                                        <form action="" method="POST">
					                                             <button type="submit" class="btn btn-danger">
					                                                <i class="glyphicon glyphicon-trash"></i>
					                                            </button>
					                                        </form>
					                                    </td>
					                                </tr>
					                            </tbody>
					                        </table>
										</div>
										<!-- Schedules Widget -->
									</div>
									<!-- Days 2 -->
								</div>
								<!-- Tab Content -->
							</div>
						</div>
						<!-- Tabs -->
					</div>
					<!-- Schedules Tabs -->

				</div>
			</section>
			<!-- Our Upcoming Schedules -->

			</div>
		</main>
		<!-- Mian Content -->
@endsection