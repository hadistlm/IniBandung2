
<!DOCTYPE html>
<html lang="en">
	
<!-- Mirrored from techlinqs.com/html/event-0.1/home-3.html by HTTrack Website Copier/3.x [XR&CO'2014], Wed, 29 Mar 2017 12:41:32 GMT -->
<head>
		<meta charset="utf-8">
		<meta http-equiv="X-UA-Compatible" content="IE=edge">
		<meta name="viewport" content="width=device-width, initial-scale=1">
		<title>Event - Event &amp; Conference Html Template, Event Html, Seminar html</title>
	    <meta name="tittle" content="Event - Event & Conference Html Template, Event Html, Seminar html">
	    <meta name="description" content="Event – Conference and Event HTML Template. It is specially designed for any Conference , Event, Meetup, Seminar, Exhibition, Congress, Meetings, Buiness Conferences, Event Management, Meet Up websites. This event site templae comes with important faetures for any kind of conefrence and event wesbites such as Speaker list more...">
	    <meta name="author" content="FineLayers">
	    <meta name="keywords" content="Event – Conference and Event, Event HTML Template, Conference, Meetup, Seminar, Exhibition, Meetings, Event Management">  
		<!-- StyleSheets -->
		<link href="{{asset('assets')}}/css/bootstrap.css" rel="stylesheet">
		<link href="{{asset('assets')}}/css/icomoon.css" rel="stylesheet">
		<link href="{{asset('assets')}}/css/aileron-font.css" rel="stylesheet">
		<link href="{{asset('assets')}}/css/animate.css" rel="stylesheet">
		<link href="{{asset('assets')}}/css/style.css" rel="stylesheet">
		<link href="{{asset('assets')}}/css/main.css" rel="stylesheet">
		<link href="{{asset('assets')}}/css/color.css" rel="stylesheet">
		<link href="{{asset('assets')}}/css/responsive.css" rel="stylesheet">
		<link href="{{asset('assets')}}/css/transition.css" rel="stylesheet">
		<!-- FontsOnline -->
		<link href="https://fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,600,600i,700,700i,800,800i" rel="stylesheet">
		<!-- JavaScripts -->
		<script src="{{asset('assets')}}/scripts/modernizr.js"></script>
	</head>
	<body>
	
	<!-- Wrapper -->
	<div class="wrapper">
		
		
@include('template.header')
@yield('content')
@include('template.footer')
