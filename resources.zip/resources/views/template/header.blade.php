<!-- Header -->
		<header id="header" class="header">

			<!-- Nav Holder -->
			<div class="nav-holder style-1 after-clear">
				
				<div class="container">
					<div class="logo-bar after-clear">

						<!-- Logo -->
						<div class="logo">
							<a href="#"><img src="{{asset('assets')}}/images/logo-1.png" alt=""></a>
						</div>
						<!-- Logo -->

						

					</div>
				</div>

				<!-- Nav & search -->
				<div class="nav-nd-search after-clear">
					<div class="container">
						<div class="p-relative after-clear">

							<!-- Nav List -->
							<nav class="dropdowns">
								<a class="toggleMenu" href="#"><i class="icon-navicon"></i></a>
								<ul class="nav-list after-clear">
									<li><a href="#">Home</a></li>
									<li><a href="#">Timeline</a></li>
									<li><a href="">Buat Festival & Event</a></li>
									<li><a href="">Panel</a></li>
									<li class="pull-right">
										<a href="" data-toggle="modal" data-target="#login"><i class="icon-sign-in"></i>Login</a>
									</li>
								</ul>

							</nav>
							

						</div>
						<div class="pull-right">

						</div>
					</div>
				</div>	
				<!-- Nav & search -->

			</div>
			<!-- Nav Holder -->